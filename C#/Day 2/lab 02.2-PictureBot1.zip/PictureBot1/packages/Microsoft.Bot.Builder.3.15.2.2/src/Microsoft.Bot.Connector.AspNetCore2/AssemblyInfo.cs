﻿using System.Reflection;

[assembly: AssemblyTitle("Microsoft.Bot.Connector.AspNetCore")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft Corporation")]
[assembly: AssemblyProduct("Microsoft Bot Framework")]
[assembly: AssemblyCopyright("Copyright © Microsoft Corporation 2016")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]


[assembly: AssemblyVersion("2.0.1.7")]
[assembly: AssemblyFileVersion("2.0.1.7")]

//[assembly: AssemblyKeyFileAttribute(@"..\\..\\buildtools\\35MSSharedLib1024.snk")] 
//[assembly: AssemblyDelaySignAttribute(true)]

[assembly: AssemblyKeyFileAttribute(@"..\\..\\buildtools\\35MSSharedLib1024.snk")] 
 [assembly: AssemblyDelaySignAttribute(true)]
